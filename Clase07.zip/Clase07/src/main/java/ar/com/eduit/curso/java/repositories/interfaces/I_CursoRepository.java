package ar.com.eduit.curso.java.repositories.interfaces;

import ar.com.eduit.curso.java.entities.Curso;
import java.util.List;

public interface I_CursoRepository {
    void save(Curso curso);                     //insert
    void remove(Curso curso);                   //delete
    void update(Curso curso);                   //update
    List<Curso> getAll();                       //select
    Curso getById(int id);                      //select where
    List<Curso>getLikeTitulo(String titulo);    //select where
}