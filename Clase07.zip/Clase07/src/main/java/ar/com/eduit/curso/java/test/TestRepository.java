package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.util.List;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        
        Curso curso=new Curso("HTML", "Nenes", Dia.VIERNES, Turno.TARDE);
        
        cr.save(curso);
        
        System.out.println(curso);
        
        System.out.println("**************************************************");
        
        List<Curso>list=cr.getAll();
        
        //recorrido por indices
        for(int a=0;a<list.size();a++){
            System.out.println(list.get(a));
        }
        
        System.out.println("**************************************************");
        
        curso=cr.getById(2);
        System.out.println(curso);
        
        System.out.println("**************************************************");
        cr.remove(cr.getById(3));
        
        System.out.println("**************************************************");
        curso=cr.getById(5);
        curso.setProfesor("Segovia");
        curso.setDia(Dia.LUNES);
        cr.update(curso);
        
        System.out.println("**************************************************");
        list=cr.getLikeTitulo("ja");
        
        //recorrido por indices
        for(int a=0;a<list.size();a++){
            System.out.println(list.get(a));
        }
        
        System.out.println("**************************************************");
        
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        
        Alumno alumno=new Alumno("Javier", "Toresi", 34, 1);
        
        ar.save(alumno);
        
        System.out.println(alumno);
        
    }
}