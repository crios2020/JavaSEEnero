package clase01;

/**
 * Clase principal del proyecto Clase01
 * @author carlos
 */
public class Clase01 {

    /**
     * Punto de entrada del proyecto.
     * @param args argumentos que ingresan por consola
     */
    public static void main(String[] args) {
        /*
        Curso:  Java Standard Web Programming   40 hs.
        Días:   Martes y Jueves 10:00 hs a 13:00 hs.
        Profe:  Carlos Ríos     carlos.rios@educacionit.com
        Materiales: alumni.educacionit.com
                    https://github.com/crios2020/JavaSEEnero
        
        Software:   JDK 8 o Sup   y un IDE
        
        JDK: Java Development Kit
        
        Versiones LTS   soporte 8 años
        
        
        IDE: Integrated Development Enviroment
        Eclipse - IntelliJ - Netbeans - JDeveloper
        
        */
        
        // Linea de comentarios
        // El usuario es muy tonto!!!
        
        /* Bloque de comentarios */
        
        /**
         * Comentario Java DOC
         * Este comentario tiene la posibilidad de ser leido desde fuera del binario ejecutable.
         * Este comentario debe ser colocado delante de la declaración de clase o de método.
         */
        
        // Tipo de datos primitivos del lenguaje
        
        // Tipo de datos Enteros
        
        // Tipo de datos Boolean        1 byte
        boolean bo=true;                // 1
        System.out.println(bo);
        bo=false;                       // 0
        System.out.println(bo);
        
        // Tipo de datos Byte           1 byte
        byte by=-128;
        System.out.println(by);
        by=0;
        System.out.println(by);
        by=127;
        System.out.println(by);
        
        // Tipo de datos short          2 bytes
        short sh=-32000;
        sh=0;
        sh=32000;
        System.out.println(sh);
        
        // Tipo de datos int            4 bytes
        int in=-2000000000;
        in=2000000000;
        System.out.println(in);
        
        // Tipo de datos long           8 bytes
        long lo=3000000000L;
        System.out.println(lo);
        
        // Tipo de datos char            2 bytes
        char ch=65;
        System.out.println(ch);
        ch+=32;
        System.out.println(ch);
        ch='x';
        System.out.println(ch);
        
        // Tipos de datos de punto flotante.
        
        //Tipo de datos float       32 bits
        float fl=4.25f;
        System.out.println(fl);
                
        //Tipo de datos double      64 bits
        double dl=4.25;
        System.out.println(dl);
        
        fl=10;
        dl=10;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        fl=100;
        dl=100;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        // Clase String
        String st="hola";
        System.out.println(st);
        
        // Tipo de datos var JDK 9 o superior.
        var var1=20;                            //int
        //var1=true;    //error
        var1=-30;
        var var2=true;                          //boolean
        var var3=2.56;                          //double
        var var4=2.56d;                         //double
        var var5=2.56f;                         //float
        var var6='a';                           //char
        var var7="a";                           //String
        var var8=20L;                           //long
        
        String texto="Esto es una cadena de texto!";
        
        //recorrer el vector texto!
        for(int a=0;a<texto.length();a++){
            System.out.print(texto.charAt(a));
        }
        System.out.println();
        
        
        //imprimir en mayusculas el vector texto
        for(int a=0;a<texto.length();a++){
            char car=texto.charAt(a);
            if(car>=90 && car<=122) car-=32;
            System.out.print(car);
        }
        System.out.println();
        
        System.out.println(texto.toUpperCase());
        System.out.println(texto.toLowerCase());
        
    }
    
}
