package clase02;

//declaración de clase
public class Auto {
    
    // Atributos
    String marca;
    String modelo;
    String color="azul";
    int velocidad;
    
    //Métodos constructores

    //Constructor vacio
    /**
     * Este método fue deprecado por Carlos Ríos el 5/1/21 por resultar inseguro.
     * Usar en su reemplazo public Auto(String marca, String modelo, int velocidad)
     * @deprecated
     */
    @Deprecated             //Annotation jdk o sup.
    public Auto() {}
    
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }
    
    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    // Métodos
    void acelerar(){                                            //acelerar
        velocidad+=10;      //velocidad=velocidad+10;
        if(velocidad>100) velocidad=100;
    }
    
    // Métodos sobrecargados
    void acelerar(int kilometros){                              //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }
    
    void acelerar(int x,int y){                                 //acelerarIntInt
        
    }
    
    void acelerar(String kilometros){                           //acelerarString
        
    }
    
    void frenar(){
        velocidad-=10;      //velocidad=velocidad-10;
    }
    
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    int obtenerVelocidad(){         //Este método tiene devolución de parametros
        return velocidad;
    }
    
    public String getEstado(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
}
