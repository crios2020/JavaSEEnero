package clase02;

public class Cuenta {

    int nro;
    String moneda;
    private double saldo;

    //método con ingreso de parametros
    void depositar(double monto) {
        saldo += monto;
    }

    void debitar(double monto) {
        if (saldo >= monto) {
            saldo -= monto;
        } else {
            System.out.println("Saldo Insufiente");
        }
    }
}
