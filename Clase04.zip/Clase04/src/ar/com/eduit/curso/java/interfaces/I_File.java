package ar.com.eduit.curso.java.interfaces;

public interface I_File {
    /*
    Interfaces en Java
    
    - Una Interface no posee constructores, ni atributos.
    - Solo puede tener atributos estaticos o constantes (final).
    - Todos los miembros de una interface son publicos.
    - Todos los métodos de una interface son abstractos (no tiene cuerpo (código))
    - Una clase puede implementar todas las interfaces que necesite y hererdar sus
        miembros.
    */
    
    /**
     * la javaDOC es heredada.
     * @param text 
     */
    void setText(String text);
    String getText();
    
    /*
        Métodos default     JDK 8 o superior
    - Un método tiene cuerpo (código).
    - Como una clase puede implementar muchas interfaces, se genera una especie 
            de herencia multiple.
    */
    default void info(){
        System.out.println("Interface I_File");
    } 
    
}