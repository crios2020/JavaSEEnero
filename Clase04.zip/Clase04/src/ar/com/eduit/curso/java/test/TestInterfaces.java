package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.interfaces.FileCloud;
import ar.com.eduit.curso.java.interfaces.FileText;
import ar.com.eduit.curso.java.interfaces.I_File;
import java.util.Scanner;

public class TestInterfaces {
    public static void main(String[] args) {
        I_File file=null;
        
        //file=new FileText();
        //file=new FileCloud();
        
        System.out.println("Ingrese 'texto' o 'nube'");
        String input=new Scanner(System.in).next();
        
        if(input.equalsIgnoreCase("texto")) file=new FileText();
        if(input.equalsIgnoreCase("nube"))  file=new FileCloud();
        
        //App
        file.setText("hola");
        System.out.println(file.getText());
        file.info();
        
        
    }
}