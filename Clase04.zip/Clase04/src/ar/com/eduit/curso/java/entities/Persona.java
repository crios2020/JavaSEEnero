package ar.com.eduit.curso.java.entities;

public abstract class Persona {
    private String nombre;
    private int edad;
    private Direccion direccion;

    //public Persona(){}
    
    public Persona(String nombre, int edad, Direccion direccion) {
        this.nombre = nombre;
        this.edad = edad;
        this.direccion = direccion;
    }
    
    //public void saludar(){
    //    System.out.println("Hola soy una Persona!");
    //}

    //un método abstracto solo puede existir en una clase abstracta
    //un método abstracto no tiene cuerpo (no tiene código), 
    //lasl clases que heredan deben implementar los métodos abstractos.
    public abstract void saludar();
    
    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", edad=" + edad + ", direccion=" + direccion + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
}