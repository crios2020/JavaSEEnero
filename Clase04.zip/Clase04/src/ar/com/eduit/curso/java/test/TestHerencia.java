package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(80000);
        cuenta1.depositar(160000);
        cuenta1.debitar(25000);
        System.out.println(cuenta1);
        
        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2,"arg$");
        cuenta2.depositar(350000);
        System.out.println(cuenta2);
        
        System.out.println("-- direccion1 --");
        Direccion direccion1=new Direccion("Lima", 222, "1", "a");
        System.out.println(direccion1);

        System.out.println("-- direccion2 --");
        Direccion direccion2=new Direccion("Belgrano", 42, null, null, "Moron");
        System.out.println(direccion2);
        
        /*
        
        //La clase Persona es Abstracta, no puedo crear objetos de una clase Abstracta
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Alan",27,direccion1);
        persona1.saludar();
        System.out.println(persona1);
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Lisandro",22,direccion1);
        persona2.saludar();
        System.out.println(persona2);
        
        System.out.println("-- persona3 --");
        Persona persona3=new Persona("Debora", 23, new Direccion("peña", 2486, "4", "e"));
        persona3.saludar();
        System.out.println(persona3);
        
        //Lisandro se mudo a la casa de Debora.
        System.out.println("Lisandro se mudo a la casa de Debora.");
        persona2.setDireccion(persona3.getDireccion());
        System.out.println(persona2);
        */
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(1, 350000, "Cristian", 36, direccion2);
        vendedor1.saludar();
        System.out.println(vendedor1);
        
        System.out.println("-- vendedor2 --");
        Vendedor vendedor2=new Vendedor(2, 400000, "Loreana",35 ,direccion1);
        vendedor2.saludar();
        System.out.println(vendedor2);
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1,cuenta1,"Juan",23,direccion1);
        cliente1.getCuenta().depositar(24000);
        cliente1.saludar();
        System.out.println(cliente1);
        
        //Polimorfirmo
        System.out.println("Polimorfismo");
        
        Persona p1 = new Vendedor(2, 30000, "Diego", 50, direccion2);
        Persona p2 = new Cliente(2, cuenta2, "Raul", 60, direccion2);
        
        p1.saludar();
        p2.saludar();
        
        Vendedor e1=(Vendedor)p1;
        Vendedor e2=(p1 instanceof Vendedor)?((Vendedor)e1):null;
        
        Vendedor e3;
        if(p1 instanceof Vendedor){
            e3=(Vendedor)e1;
        }else{
            e3=null;
        }
        
    }
}