package ar.com.eduit.curso.java.interfaces;

public class FileCloud implements I_File{

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo de Nube");
    }

    @Override
    public String getText() {
        return "Archivo de Nube!";
    }

}