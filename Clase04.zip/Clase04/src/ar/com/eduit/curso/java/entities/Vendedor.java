package ar.com.eduit.curso.java.entities;

public class Vendedor extends Persona {
    private int nroLegajo;
    private double sueldoBasico;

    public Vendedor(int nroLegajo, double sueldoBasico, String nombre, int edad, Direccion direccion) {
        super(nombre, edad, direccion); //llama al constructor de la clase Padre
        this.nroLegajo = nroLegajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public void saludar(){
        System.out.println("Hola soy un Vendedor!");
    }
    
    @Override
    public String toString() {
        return super.toString()+" Vendedor{" + "nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + '}';
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }
  
}