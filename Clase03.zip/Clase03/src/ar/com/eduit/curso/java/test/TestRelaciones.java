package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.List;

public class TestRelaciones {
    public static void main(String[] args) {
        
        // Objetos MOCKS (Objetos Simulados)
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(80000);
        cuenta1.depositar(160000);
        cuenta1.debitar(25000);
        System.out.println(cuenta1);
        
        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2,"arg$");
        cuenta2.depositar(350000);
        System.out.println(cuenta2);
        
        
        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(1,"Andres",24,10);
        clientePersona1.getCuenta().depositar(25000);
        
        Cuenta cuentaClientePersona1=clientePersona1.getCuenta();
        cuentaClientePersona1.depositar(20000);
        
        clientePersona1.getCuenta().debitar(10000);
        
        clientePersona1.comprar();
        
        System.out.println(clientePersona1);
        
        System.out.println("-- clientePersona2 --");
        ClientePersona clientePersona2=new ClientePersona(2,"Eliana",22,11);
        clientePersona2.getCuenta().depositar(60000);
        clientePersona2.comprar();
        System.out.println(clientePersona2);
        
        
        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1,"Todo Limpio srl","Lima 111");
        List<Cuenta> list=clienteEmpresa1.getCuentas();
        list.add(cuenta1);                          // 0
        list.add(cuenta2);                          // 1
        list.add(new Cuenta(100,"U$S"));            // 2
        list.get(0).depositar(120000);
        list.get(0).debitar(23000);
        list.get(1).depositar(35000);
        list.get(2).depositar(12000);
        //list.remove(1);
        
        clienteEmpresa1.comprar();
        
        System.out.println(clienteEmpresa1);
        
        // recorrido de la lista con indices
        for(int a=0;a<list.size();a++){
            System.out.println(list.get(a));
        }
        
        
        
        
        
    }
}
