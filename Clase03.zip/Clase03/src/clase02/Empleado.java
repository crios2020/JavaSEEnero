package clase02;

import java.text.DecimalFormat;

public class Empleado {
    private int nroLegajo;
    private String nombre;
    private String apellido;
    private int edad;
    private float sueldoBasico;

    public Empleado(int nroLegajo, String nombre, String apellido, int edad, float sueldoBasico) {
        this.nroLegajo = nroLegajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public String toString() {
        return "Empleado{" + 
                "nroLegajo=" + nroLegajo + 
                ", nombre=" + nombre + 
                ", apellido=" + apellido + 
                ", edad=" + edad + 
                ", sueldoBasico=" + new DecimalFormat("###,###,###,###.00").format(sueldoBasico) + '}';
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        // control de sessión
        this.apellido = apellido;
        // insert into table auditoria (values)
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(float sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }

}