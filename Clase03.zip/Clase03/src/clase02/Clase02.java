package clase02;

import javax.swing.JOptionPane;


public class Clase02 {
    public static void main(String[] args) {
        /*// TODO code application logic here
            Clase 02 POO
        
        Que es una clase? una clase todo lo que detecta como sustantivo en un
        ambito laboral.
        
        En Java una clase es un objeto de la clase java.lang.Class
        
        
        Que son los atributos? son caracteristas(adjetivos) de una clase. 
            son variables contenidas dentro de una clase
        
        En Java los atributos son clase de la clase java.lang.reflect.Field
        
        Que son los métodos? son acciones que realiza clase(verbos) 
        
        En Java los métodos son objetos de la clase java.lang.reflect.Method
        
        
        Que son los objetos? Los objetos son instancias de la clase y representan
            una situación en particular, cada objeto tiene un estado propio, es decir
            el objeto completa valor a los atributos.
        
        Los atributos tiene un proceso de inicialización automatico, los atributos númericos
        se inicializan en 0, los atributos tipo String se inicializan en null.
        
        Las variables locales no se inicializan automaticamente.
        
        
        Que son los constructores? son métodos que inicializan un objetos, tiene el mismo nombre
            que la clase y no tienen devolución de parametros.
        Los constructores pueden ser sobrecargados
        Se invoka un constructor usando la palabra clave new.
        Si una clase no tiene constructor, Java al compilar le crea un constructor vacio.
        
        En Java los constructores son objetos de la clase java.lang.reflect.Constructors
        
        */
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();          //se construye un objeto
        auto1.marca="Fiat";
        auto1.modelo="Cronos";
        auto1.color="Rojo";
        auto1.acelerar();       //10
        auto1.acelerar();       //20
        auto1.acelerar();       //30
        auto1.frenar();         //20
        auto1.acelerar(13);     //33
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Citroen";
        auto2.modelo="Berlingo";
        auto2.color="Verde";
        
        for(int a=0;a<=50;a++) auto2.acelerar();
        
        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
      
        
        //String texto;
        //int x;
        
        //System.out.println(texto);  //error variable no inicializada
        //System.out.println(x);      //error variable no inicializada
        
        
        //Devolución de parametros
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Ford", "Ka", "Negro");
        auto3.acelerar(42);
        
        auto3.imprimirVelocidad();
        System.out.println(auto3.obtenerVelocidad());
        
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.obtenerVelocidad());
        
        //método .toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        System.out.println(auto3.getEstado());
        
        Empleado e1=new Empleado(1, "Ana", "Salina", 26, 200000);
        
        //e1.sueldoBasico=20000000;
        e1.setSueldoBasico(20000000);
        
        System.out.println(e1);
        
        
        
        
        /*
        Modificadores de visibilidad para Miembros de clases (Atributos o Métodos)
        
        Modicador               Alcance
        default omitido         Solo es accesible desde la misma clase y 
                                desde clases del mismo paquete.
        
        public                  Es accesible desde la misma clase y desde clases
                                de cualquier paquete.
        
        private                 Solo se puede acceder desde la misma clase.
        
        protected               Es accesible desde la misma clase, desde clases
                                hijas y desde clases del mismo paquete.
        
        
        */
        
        auto3.color="Negro";
        
    }
    
}
