package clase03;

import clase02.Auto;

public class Clase03 {
    public static void main(String[] args) {
        Auto auto=new Auto("Peugeot", "3008", "Gris");
        //auto.color="Rojo";
    }
}
