package collections;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

public class App {
    public static void main(String[] args) {
        
        //Vector - Array
        Auto[] autos =new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Blanco");
        autos[1]=new Auto("Ford","Ka","Negro");
        autos[2]=new Auto("Peugeot","2008","Verde");
        autos[3]=new Auto("Renaul","Clio","Rojo");
        
        //Recorrido por indices
        //for(int a=0; a<autos.length; a++) System.out.println(autos[a]);
        
        //Esctructura forEach       JDK 5 o superior
        for(Auto a:autos) System.out.println(a);
        
        //Framework Collections
        
        //Interface List    Representa una lista tipo vector con indices
        List lista1;            //Object
        
        lista1=new ArrayList();
        //lista1=new LinkedList();
        //lista1=new Vector();
        
        
        lista1.add(new Auto("Chevrolet","Corsa","Gris"));       // 0
        lista1.add(new Auto("VW","UP","Blanco"));               // 1
        lista1.add("hola");                                     // 2
        lista1.add(26);                                         // 3
        lista1.add(2, "lunes");
        lista1.remove("hola");
        
        //Copiar los autos del vector autos a lista1
        for(Auto a:autos) lista1.add(a);
        
        //recorrido con indices
        System.out.println("*************************************************");
        //for(int a=0; a<lista1.size(); a++) System.out.println(lista1.get(a));
        
        //recorrido forEach
        //for(Object o:lista1) System.out.println(o);
        
        //método default .forEach()  JDK 8 o sup.
        //lista1.forEach(o->System.out.println(o));
        lista1.forEach(System.out::println);
        
        
        //Uso de generics <> JDK 5 o sup.
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Citroen","C4","Bordo"));
        lista2.add(new Auto("Citroen","Berlingo","Negro"));
        
        Auto auto1=(Auto)lista1.get(0);
        Auto auto2=lista2.get(0);
        
        // Copiar autos de lista1 a lista2
        
        /*
        for(Object o:lista1){
            if(o instanceof Auto) lista2.add((Auto)o); 
        }
        */
        
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o); 
        });
        
        
        System.out.println("*************************************************");
        lista2.forEach(System.out::println);
        
        //Interface Set: Representa una lista sin indices, 
        //      el mismo objeto almacenado es el indice.
        //      No hay objetos repetidos en SET. (Lista sin duplicados)
        
        Set<String> set;
        
        //Implementación HashSet: Almacena y recupera elementos de la forma más veloz
        //      posible, No garantiza el orden de los elementos.
        //set=new HashSet();
        
        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada
        //      por orden de ingreso.
        //set=new LinkedHashSet();
        
        //Implementación TreeSet: Almacena elementos en un arbol por orden natural
        //                          (por orden alfabetico)
        set=new TreeSet();
        
        System.out.println("*************************************************");
        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Lunes");
        set.add("Jueves");
        set.add("Viernes");
        set.forEach(System.out::println);
        
        System.out.println("*************************************************");
        lista2.forEach(lista1::add);
        
        Set<Auto> setAutos;
        
        //setAutos=new HashSet();
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();
        
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Chevrolet","Corsa","Gris"));
        
        System.out.println("*************************************************");
        //setAutos.forEach(System.out::println);
        setAutos.forEach(a->System.out.println(a+"\t"+a.hashCode()));
        
        //Ana,Perez,009
        //Ana,Perez,011
     
        int edad1=9;
        int edad2=11;
        DecimalFormat dfEdad=new DecimalFormat("000"); 
        System.out.println(dfEdad.format(edad1));
        System.out.println(dfEdad.format(edad2));
        
        
        DecimalFormat df=new DecimalFormat("###,###,###.00"); 
        float precio=1000000;
        System.out.println(df.format(precio));
        
        /*
        Pilas y Cola
        
        Pila - Stack LIFO   Last In First Out
        
        Cola - Queue FIFO   First In First Out
        
        */
        
        //Clase Stack Pilas
        Stack<Auto> pilaAutos=new Stack();
        
        //método .push() apila un auto
        pilaAutos.push(new Auto("Fiat","Uno","Blanco"));
        pilaAutos.addAll(lista2);
        
        System.out.println("*************************************************");
        pilaAutos.forEach(System.out::println);
        
        //Interface Queue
        
        
        //Interfaces Map
        
        //Api Stream
        
        
    }
}