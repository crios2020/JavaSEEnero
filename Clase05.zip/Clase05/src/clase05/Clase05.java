package clase05;

import java.io.File;
import java.io.FileReader;

public class Clase05 {
    public static void main(String[] args){
        // Clase 05 - Manejo de Exceptions
        
        //System.out.println(10/0);
        //System.out.println("Esta linea no se ejecuta!!!");
        
        /*
            Estructura try - catch - finally
        
        try {                               //Obligatorio
            - Colocar las sentencias que pueden arrojar una Exception (Error).
            - Estas sentencias tienen mayor costo de hardware.
            - Si se puede ejecutar sin errores, termina el bloque try exitosamente.
            - En caso de Exception (error) se detiene el control del bloque try
                y inicia el control del bloque catch.
        } catch (Exception e) {             //Obligatorio
            - Este bloque se ejecuta en caso de Exception. (No se detiene la ejecución)
            - Se recibe como parametro un Objeto de Exception con los detalles del error.
            - Los objetos o variables declarados en try no son visibles 
                    (fuera de scope).
        } finally {                         //Opcional
            - Este bloque se ejecuta siempre, exista Exception o no
            - Los Objetos o Variables declarados en bloque try o catch, no son
                accesible (fuera de scope)
        }

        - Estas sentencias se ejecutan siempre.
        - Los Objetos o Variables declarados en bloque try catch o finally, no son
                accesible (fuera de scope)
        - El programa termina normalmente.
        */
        
        /*
        int x=2;
        {   //bloque de software
            int y=4;
            System.out.println(x);
            System.out.println(y);
            x++;
        }
        
        System.out.println(x);
        //System.out.println(y); //fuera de scope
        
        int y=5;
        */
        
        /*
        try {
            System.out.println(10/0);
            System.out.println("Esta linea no se ejecuta!");
        } catch (Exception e) {
            System.out.println("Ocurrio un error!!");
            System.out.println(e);
        } finally {
            System.out.println("Termino la estructura try - catch - finally");
        }
        System.out.println("El programa termina normalmente!!");
        */
        
        //GeneradorDeExceptions.generar();
        
        try {
            //GeneradorDeExceptions.generar();
            //GeneradorDeExceptions.generar(true);
            //GeneradorDeExceptions.generar("23x");
            //GeneradorDeExceptions.generar(null, 2);
            //GeneradorDeExceptions.generar("hola", 10);
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //Captura personalizada de Exceptions
        try {
            //GeneradorDeExceptions.generar();
            //FileReader in=new FileReader(new File("texto"));
        //} catch (ArrayIndexOutOfBoundsException e)  { System.out.println("Indice fuera de rango!");
        } catch (NumberFormatException e)           { System.out.println("Formato de número incorrecto!");
        } catch (ArithmeticException e)             { System.out.println("División / 0");
        } catch (NullPointerException e)            { System.out.println("Puntero Nulo!");
        //} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
        //} catch(ArrayIndexOutOfBoundsException |  StringIndexOutOfBoundsException e) {
            //Captura Multiple de Exceptiones
        //    System.out.println("Indice fuera de rango!");
        } catch(IndexOutOfBoundsException e)        { System.out.println("Indice fuera de rango!");
        } catch (Exception e) {
            System.out.println("Ocurrio un error no esperado!");
        }
        
        
        // Checked Exceptions - Unchecked Exceptions (RuntimeException)
        
        // Unchecked Exception
        GeneradorDeExceptions.generar(false);
        
        // Checked Exception
        try {
            //FileReader in=new FileReader(new File("texto.txt"));
        } catch(Exception e){
            System.out.println(e);
        }
        
        
        // Validar Reglas de negocio con Exceptions
        Vuelo v1=new Vuelo("AER1234", 100);
        Vuelo v2=new Vuelo("LAT1111", 100);
        
        try{
            v1.venderPasajes(40);
            v2.venderPasajes(20);
            v1.venderPasajes(50);
            v2.venderPasajes(30);
            v1.venderPasajes(30);               //Lanza una exception
            v2.venderPasajes(10);               //Esta venta no se realiza
        }catch(Exception e){
            System.out.println(e);
        }
        
        
        // try with resources JDK 7
        
        /*
        //Esto no se debe hacer!!!!!!!!!!!!!!!!!!!!!!
        FileReader in=null;
        try {
            in=new FileReader(new File("texto.txt"));
            System.out.println(in.read());
            in.close();
        } catch (Exception e) {
            System.out.println(e);
            if(in!=null){
                try{
                    in.close();
                }catch(Exception ex){
                    System.out.println(ex);
                }
            }
        }
        */

        //Usar de esta forma
        // de esta forma java ejecuta el método .close() siempre.
        try ( FileReader in = new FileReader(new File("texto.txt")) ) {        //Usando try with resources JDK 7
            System.out.println(in.read());
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }
    
}
