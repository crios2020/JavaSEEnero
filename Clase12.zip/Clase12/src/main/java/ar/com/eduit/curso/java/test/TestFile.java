package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.files.FileText;
import ar.com.eduit.curso.java.files.I_File;
import java.util.List;
import java.util.stream.Collectors;

public class TestFile {
    public static void main(String[] args) {
        String file="res/texto.txt";
        I_File fText=new FileText(file);
        
        fText.setText("Curso de Java!!\n");
        fText.appendText("Hoy es Martes!\n");
        fText.addLine("Lunes.");
        fText.addLine("Martes.");
        fText.addLine("Miércoles.");
        fText.addLine("Jueves.");
        fText.addLine("Viernes.");
        fText.addLine("Sábado.");
        fText.addLine("Domingo.");
        fText.addLine("Lunes.");
        
        List<String>semana=List.of("Primavera.","Verano.","Otoño.","Invierno.","Primavera.");
        
        fText.addLines(semana);
        
        //System.out.println(fText.getText());
        //fText.print();
        
        //fText.getAll().forEach(System.out::println);
        
        //mostrar solo filas que contengan la lentra M.
        fText
                .getAll()
                .stream()
                .filter(s->s.toLowerCase().contains("m"))
                .collect(Collectors.toSet())
                .forEach(System.out::println);
        
        
        
        
    }
}