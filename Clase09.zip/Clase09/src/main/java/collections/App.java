package collections;

import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;


public class App {
    public static void main(String[] args) {
        
        //Vector - Array
        Auto[] autos =new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Blanco");
        autos[1]=new Auto("Ford","Ka","Negro");
        autos[2]=new Auto("Peugeot","2008","Verde");
        autos[3]=new Auto("Renaul","Clio","Rojo");
        
        //Recorrido por indices
        //for(int a=0; a<autos.length; a++) System.out.println(autos[a]);
        
        //Esctructura forEach       JDK 5 o superior
        for(Auto a:autos) System.out.println(a);
        
        //Framework Collections
        
        //Interface List    Representa una lista tipo vector con indices
        List lista1;            //Object
        
        lista1=new ArrayList();
        //lista1=new LinkedList();
        //lista1=new Vector();
        
        
        lista1.add(new Auto("Chevrolet","Corsa","Gris"));       // 0
        lista1.add(new Auto("VW","UP","Blanco"));               // 1
        lista1.add("hola");                                     // 2
        lista1.add(26);                                         // 3
        lista1.add(2, "lunes");
        lista1.remove("hola");
        
        //Copiar los autos del vector autos a lista1
        for(Auto a:autos) lista1.add(a);
        
        //recorrido con indices
        System.out.println("*************************************************");
        //for(int a=0; a<lista1.size(); a++) System.out.println(lista1.get(a));
        
        //recorrido forEach
        //for(Object o:lista1) System.out.println(o);
        
        //método default .forEach()  JDK 8 o sup.
        //lista1.forEach(o->System.out.println(o));
        lista1.forEach(System.out::println);
        
        
        //Uso de generics <> JDK 5 o sup.
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Citroen","C4","Bordo"));
        lista2.add(new Auto("Citroen","Berlingo","Negro"));
        
        Auto auto1=(Auto)lista1.get(0);
        Auto auto2=lista2.get(0);
        
        // Copiar autos de lista1 a lista2
        
        /*
        for(Object o:lista1){
            if(o instanceof Auto) lista2.add((Auto)o); 
        }
        */
        
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o); 
        });
        
        
        System.out.println("*************************************************");
        lista2.forEach(System.out::println);
        
        //Interface Set: Representa una lista sin indices, 
        //      el mismo objeto almacenado es el indice.
        //      No hay objetos repetidos en SET. (Lista sin duplicados)
        
        Set<String> set;
        
        //Implementación HashSet: Almacena y recupera elementos de la forma más veloz
        //      posible, No garantiza el orden de los elementos.
        //set=new HashSet();
        
        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada
        //      por orden de ingreso.
        //set=new LinkedHashSet();
        
        //Implementación TreeSet: Almacena elementos en un arbol por orden natural
        //                          (por orden alfabetico)
        set=new TreeSet();
        
        System.out.println("*************************************************");
        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Lunes");
        set.add("Jueves");
        set.add("Viernes");
        set.forEach(System.out::println);
        
        System.out.println("*************************************************");
        lista2.forEach(lista1::add);
        
        Set<Auto> setAutos;
        
        //setAutos=new HashSet();
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();
        
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Chevrolet","Corsa","Gris"));
        
        System.out.println("*************************************************");
        //setAutos.forEach(System.out::println);
        setAutos.forEach(a->System.out.println(a+"\t"+a.hashCode()));
        
        //Ana,Perez,009
        //Ana,Perez,011
     
        int edad1=9;
        int edad2=11;
        DecimalFormat dfEdad=new DecimalFormat("000"); 
        System.out.println(dfEdad.format(edad1));
        System.out.println(dfEdad.format(edad2));
        
        
        DecimalFormat df=new DecimalFormat("###,###,###.00"); 
        float precio=1000000;
        System.out.println(df.format(precio));
        
        /*
        Pilas y Cola
        
        Pila - Stack LIFO   Last In First Out
        
        Cola - Queue FIFO   First In First Out
        
        */
        
        //Clase Stack Pilas
        Stack<Auto> pilaAutos=new Stack();
        
        //método .push() apila un auto
        pilaAutos.push(new Auto("Fiat","Uno","Blanco"));
        pilaAutos.addAll(lista2);
        
        System.out.println("*************************************************");
        pilaAutos.forEach(System.out::println);
        
        System.out.println("Longitud de pila: "+pilaAutos.size());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
            // .pop() desapila un elemento.
        } 
        System.out.println("Longitud de pila: "+pilaAutos.size());
        
        //Interface Queue
        ArrayDeque<Auto>colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("VW","GOL","Rojo"));
        // .offer() Encola un elemento
        colaAutos.addAll(lista2);
        
        System.out.println("****************************************************");
        colaAutos.forEach(System.out::println);
        
        System.out.println("Longitud de cola: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
            // .poll() desencola un elemento
        }
        System.out.println("Longitud de cola: "+colaAutos.size());
        
        //Interfaces Map, Representa un vector asociativo o diccionario
        Map<String,String>map;
        
        //Implementación HashMap: Es la implementación más veloz, no garantiza el orden
        //      de los elementos.
        //map=new HashMap();
        
        //Implementación Hashtable: funciona igual que HashMap pero es legacy (obsoleta).
        //map=new Hashtable();
        
        //Implementación LinkedHashMap: Almacena elementos en una lista enlazada por 
        //      orden de ingreso.
        map=new LinkedHashMap();
        
        // Implementación TreeMap: Almacena en un arbol por orden natural de claves.
        //      La clase de la clave debe implementar la interface Comparable.
        map=new TreeMap();
        
        map.put("lu", "Lunes");
        map.put("ma", "Martes");
        map.put("mi", "Miércoles");
        map.put("ju", "Jueves");
        map.put("vi", "Viernes");
        map.put("sa", "Sábado");
        map.put("do", "Domingo");
        
        System.out.println(map.get("vi"));
        System.out.println("****************************************************");
        map.forEach((k,v)->System.out.println(k+" - "+v));
        
        
        //Api Stream JDK 8
        
        System.out.println("****************************************************");
        //select * from autos;
        lista2.stream().forEach(System.out::println);
        
        //select * from autos where color = 'rojo'
        System.out.println("****************************************************");
        
        //for(Auto a:lista2){
        //    if(a.getColor().equalsIgnoreCase("rojo")){
        //        System.out.println(a);
        //    }
        //}
        
        lista2
                .stream()
                .filter(a->a.getColor().equalsIgnoreCase("rojo"))
                .forEach(System.out::println);
        
        
    }
}