package consecionaria.app;

import consecionaria.entities.Auto;
import consecionaria.entities.Moto;
import consecionaria.entities.Vehiculo;
import consecionaria.repositories.I_VehiculoRepository;
import consecionaria.repositories.VehiculoRepository;
import java.util.Comparator;

public class Consecionaria {

    private static I_VehiculoRepository vr = new VehiculoRepository();

    public static void main(String[] args) {

        // Cargar la lista de vehículos
        cargar();

        // Imprimir listado.
        imprimir();

        // Separador.
        separador();

        // Vehículo más caro.
        vehiculoMasCaro();
        
        // Vehículo más barato.
        vehiculoMasBarato();
        
        // Vehículo que contiene en el modelo la letra ‘Y’
        vehiculoY();
        
        // Separador.
        separador();
        
        // Vehículos ordenados por precio de mayor a menor.
        vehiculosOrdenadosPrecio();
        
        // Separador.
        separador();
        
        // Vehículos ordenados por orden natural.
        vehiculosOrdenNatural();

    }
    
    private static void vehiculosOrdenadosPrecio(){
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vr
                .getAll()
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
    }
    
    private static void vehiculosOrdenNatural(){
        System.out.println("Vehículos ordenados por orden natural:");
        vr.getAll().stream().sorted().forEach(System.out::println);
    }
    
    private static void vehiculoY(){
        // Puede existir más de un vehiculo con el modelo que contenga "Y"
        
        // Opción solo Y mayuscula
        /*
        vr
                .getAll()
                .stream()
                .filter(v->v.getModelo().contains("Y"))
                .forEach(v->{
                    System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "
                        +v.getMarca()+" "+v.getModelo()+" $"+v.getPrecioFormat());
                });
        */
        
        // Opción solo Y mayuscula o minuscula
                vr
                .getAll()
                .stream()
                .filter(v->v.getModelo().toLowerCase().contains("y"))
                .forEach(v->{
                    System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "
                        +v.getMarca()+" "+v.getModelo()+" $"+v.getPrecioFormat());
                });
    }

    private static void vehiculoMasCaro() {
        // Vehículo más caro.
        // Esta solución no contempla que puede existir dos vehículos o más con el precio máximo
        //Vehiculo vehiculoMaxPrecio = vr.getAll().stream().max(Comparator.comparingDouble(Vehiculo::getPrecio)).get();
        //System.out.println("Vehículo más caro: "+vehiculoMaxPrecio.getMarca() + " " + vehiculoMaxPrecio.getModelo());
        
        // *********************************************************************
        
        // Lista de Vehículos con el precio más caro
        // Esta solución contempla más de un vehiculo con el precio máximo.
        double precioMaximo = vr
                                .getAll()
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
        vr
                .getAll()
                .stream()
                .filter(v->v.getPrecio()==precioMaximo)
                .forEach(v->System.out.println("Vehículo más caro: "+v.getMarca()+" "+v.getModelo()));
    }
    
    private static void vehiculoMasBarato(){
        // Vehículo más barato.
        // Esta solución no contempla que puede existir dos vehículos o más con el precio mínimo
        //Vehiculo vehiculoMinPrecio = vr.getAll().stream().min(Comparator.comparingDouble(Vehiculo::getPrecio)).get();
        //System.out.println("Vehículo más barato: "+vehiculoMinPrecio.getMarca() + " " + vehiculoMinPrecio.getModelo());
        
        // *********************************************************************
        
        // Lista de Vehículos con el precio más barato
        // Esta solución contempla más de un vehiculo con el precio mínimo.
        double precioMinimo = vr
                                .getAll()
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
        vr
                .getAll()
                .stream()
                .filter(v->v.getPrecio()==precioMinimo)
                .forEach(v->System.out.println("Vehículo más barato: "+v.getMarca()+" "+v.getModelo()));
    }

    private static void imprimir() {
        vr.getAll().forEach(System.out::println);
    }

    private static void cargar() {
        vr.save(new Auto("Peugeot", "206", 200000, 2));
        vr.save(new Moto("Honda", "Titan", 60000, 125));
        vr.save(new Auto("Peugeot", "208", 250000, 5));
        vr.save(new Moto("Yamaha", "YBR", 80500.5, 160));
        //vr.save(new Moto("Honda", "PCX", 250000, 150));
        //vr.save(new Moto("Honda", "Wave", 60000, 110));
        //vr.save(new Moto("Zanella", "Styler", 160000, 160));
    }

    private static void separador() {
        System.out.println("\n=============================\n");
    }
}
