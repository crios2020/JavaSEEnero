package consecionaria.repositories;

import consecionaria.entities.Vehiculo;
import java.util.List;

public interface I_VehiculoRepository {
    void save(Vehiculo vehiculo);
    List<Vehiculo>getAll();
}